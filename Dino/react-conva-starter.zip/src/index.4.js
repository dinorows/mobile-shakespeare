import { Circle } from 'react-konva';
import Konva from 'konva';
import React from 'react';
import { render } from 'react-dom';
import { Stage, Layer, Star, Text } from 'react-konva';

const App = () => {
  const [color, setColor] = React.useState('black');

  return (
    <Stage width={window.innerWidth} height={window.innerHeight}>
      <Layer>
	    <Text text="Try to drag the circle" />
		<Circle
		  x={500}
		  y={500}
		  draggable
		  radius={100}
		  fill={color}
		  onDragEnd={() => {
			setColor(Konva.Util.getRandomColor());
		  }}
		/>
	  </Layer >
	</Stage>
  );
};

render(<App />, document.getElementById('root'));